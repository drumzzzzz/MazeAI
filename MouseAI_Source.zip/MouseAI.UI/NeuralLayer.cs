﻿// NeuralLayer Class:
// Control utilized for neural layer selections in the training settings

using System.Windows.Forms;

namespace MouseAI.UI
{
    public partial class NeuralLayer : UserControl
    {
        public NeuralLayer()
        {
            InitializeComponent();
        }
    }
}
